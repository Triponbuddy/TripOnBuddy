//
//  CustomChatBubbleView.swift
//  TripOnBuddy
//
//  Created by Sunil Sharma on 03/06/24.
//

import SwiftUI



struct CustomChatBubbleView: View {
    let messages = ["Hello World"]
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CustomChatBubbleView()
}
