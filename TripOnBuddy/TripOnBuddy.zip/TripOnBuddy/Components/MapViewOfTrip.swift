//
//  MapViewOfTrip.swift
//  TripOnBuddy
//
//  Created by Sunil Sharma on 2024-12-27.
//

import SwiftUI

struct MapViewOfTrip: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    MapViewOfTrip()
}
