//
//  MapsViewOfTrip.swift
//  TripOnBuddy
//
//  Created by Sunil Sharma on 2024-12-27.
//

import SwiftUI

struct MapsViewOfTrip: View {
    var body: some View {
        
       Text("Hello")
    }
}

#Preview {
    MapsViewOfTrip()
}
