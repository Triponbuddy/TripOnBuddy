//
//  ProfileView.swift
//  TripOnBuddy
//
//  Created by Sunil Sharma on 18/03/24.
//

import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var authViewModel: AuthViewModel // For user authentication
    @StateObject private var viewModel = ProfileViewModel() // ViewModel for Profile
    
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .frame(width: 70, height: 70)
                        Text(authViewModel.currentUser?.fullName ?? "full Name")
                            .font(.system(size: 16))
                        Text("@\(authViewModel.currentUser?.userName ?? "userName")")
                            .font(.system(size: 14))
                        
                        Text(authViewModel.currentUser?.bio ?? "")
                            .font(.system(size: 16))
                    }
                    .padding(.top, 10)
                    Spacer()
                    VStack {
                        
                        Text("0")
                            .bold()
                        Text("Buddies")
                    }
                    
                    Spacer()
                }
                Spacer()
                ScrollView {
                    if viewModel.isLoading {
                        ProgressView("Loading posts...")
                    } else if viewModel.errorMessage != nil {
                        Text("Can't retrieve Posts")
                            .foregroundColor(.red)
                    } else if viewModel.userPosts.isEmpty {
                        Text("You haven't posted anything yet.")
                            .foregroundColor(.gray)
                    } else {
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 3) {
                            ForEach(viewModel.userPosts) { post in
                                AsyncImage(url: URL(string: post.imageUrl)) { image in
                                    image
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 140, height: 140)
                                        .clipped()
                                } placeholder: {
                                    Rectangle()
                                        .fill(Color.gray.opacity(0.2))
                                        .frame(width: 100, height: 100)
                                        .cornerRadius(8)
                                }
                                
                            }
                        }
                    }
                }
            }
            .toolbar(content: {
                ToolbarItem(placement: .topBarLeading,
                            content: {
                    Text(authViewModel.currentUser?.userName.capitalized ?? "TripOnBuddy")
                        .font(.title)
                        .bold()
                    
                })
                
                ToolbarItem(placement: .topBarTrailing,
                            content: {
                    Image(systemName: "line.3.horizontal")
                    
                })
            })
            .onAppear {
                Task {
                    await viewModel.fetchUserPosts()
                }
            }
            .padding(.horizontal, 8)
        }
    }
    
}

#Preview {
    ProfileView()
        .environmentObject(AuthViewModel())
}
