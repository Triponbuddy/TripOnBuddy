//
//  AddCaptionViewToPost.swift
//  TripOnBuddy
//
//  Created by Sunil Sharma on 2024-12-28.
//

import SwiftUI
import Firebase

struct AddCaptionViewToPost: View {
    let selectedImage: UIImage
    let userName: String
    let fullName: String
    
    @State private var caption: String = ""
    @EnvironmentObject var postViewModel: PostViewModel
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    Text(fullName.capitalized)
                        .font(.headline)
                    
                    
                    Spacer()
                    
                }
                Image(uiImage: selectedImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: UIScreen.main.bounds.width - 10, height: 400)
                    .cornerRadius(10)
                    .padding(5)
                Divider()
                TextField("Add a caption...", text: $caption, axis: .vertical)
                    .padding()
                    .lineLimit(0...100)
                Spacer()
                
            }
            .padding(.horizontal, 8)
            .toolbar {
                ToolbarItem(placement: .topBarLeading, content: {
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .bold()
                            .frame(maxWidth: .infinity)
                            .foregroundColor(Color.nileBlue)
                    }
                })
                ToolbarItem(placement: .topBarTrailing, content: {
                    Button(action: {
                        Task {
                            await postViewModel.uploadMediaPost(
                                image: selectedImage,
                                userName: userName,
                                fullName: fullName,
                                caption: caption
                            ) { success in
                                if success {
                                    print("Post uploaded successfully.")
                                    DispatchQueue.main.async {
                                        dismiss()
                                    }
                                } else {
                                    print("Failed to upload post.")
                                }
                            }
                        }
                    }) {
                        Text("Post")
                            .bold()
                            .frame(maxWidth: .infinity)
                            .foregroundColor(Color.nileBlue)
                    }
                })
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    
}


#Preview {
    AddCaptionViewToPost(selectedImage: .demo, userName: "example", fullName: "Sunil Sharma" )
}
